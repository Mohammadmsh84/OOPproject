import java.sql.*;

public class MySQLRetrieveItems {

    public static void main(String[] args) {
        // Set your MySQL database credentials
        final String url = "jdbc:mysql://localhost:3306/CityWarsTokyoReign";
        final String user = "root";
        final String password = "sam@rad20";

        try {
            // Establish a connection to the database
            Connection connection = DriverManager.getConnection(url, user, password);

            // Create a statement object for executing SQL queries
            Statement statement = connection.createStatement();

            // Define the SQL query to retrieve items from a table
            String query = "SELECT * FROM your_table";

            // Execute the query
            ResultSet resultSet = statement.executeQuery(query);

            // Iterate over the retrieved items
            while (resultSet.next()) {
                // Access columns by name or index
                String column1Value = resultSet.getString("column1");
                String column2Value = resultSet.getString("column2");
                // Print or process retrieved values as needed
                System.out.println(column1Value + ", " + column2Value);
            }

            // Close the result set, statement, and connection
            resultSet.close();
            statement.close();
            connection.close();

        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
        }
    }
}
