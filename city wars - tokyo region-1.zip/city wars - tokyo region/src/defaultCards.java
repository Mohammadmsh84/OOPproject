import java.util.ArrayList;
import java.util.List;

public class defaultCards extends Cards {

    private String Name;
    private int accuracy, duration, price, player_damage;

    public static List<defaultCards> default_cards = new ArrayList<>();

    public defaultCards(int accuracy, int duration, int price, int player_damage, String Name) {
        super(accuracy, duration, price, player_damage, Name);
        default_cards.add(this);
    }

    public void setCard_name(String card_name) {
        this.Name = card_name;
    }

    public String getCard_name() {
        return Name;
    }

    public void set_accuracy(int p) {
        this.accuracy=p;
    }

    public int get_accuracy() {
        return this.accuracy;
    }

    public void set_duration(int i) {
        this.duration=i;
    }

    public int getDuration() {
        return duration;
    }

    public void setPlayer_damage(int player_damage) {
        this.player_damage = player_damage;
    }

    public int getPlayer_damage() {
        return player_damage;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }
}