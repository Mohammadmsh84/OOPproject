CREATE DATABASE CityWarsTokyoReign;

USE CityWarsTokyoReign;

CREATE TABLE users if not exists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nickname VARCHAR(50),
    gmail VARCHAR(100),
    security_question INT,
    security_answer VARCHAR(255),
    level INT DEFAULT 1,
    xp int DEFAULT=0,
    coins INT DEFAULT 0
);

CREATE TABLE cards if not exists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username INT,
    card_name VARCHAR(50),
    level INT,
    FOREIGN KEY (username) REFERENCES users(username)
);

CREATE TABLE game_history if not exists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username varchar(50),
    game_date DATETIME,
    result VARCHAR(50),
    FOREIGN KEY (username) REFERENCES users(username)
);

create TABLE player if not exists (
    id int primary key AUTO_INCREMENT,
    username varchar(50),
    damage int DEFAULT=0,
    hp int DEFAULT=0,
    turns_left int DEFAULT=4,

    FOREIGN key username REFERENCES users(username)
)