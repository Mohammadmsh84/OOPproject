import java.util.ArrayList;
import java.util.List;

public class ClanWars extends game {

    public ClanWars(Clans clan1, Clans clan2) {

        super(4, 6);
        Boolean[][] results = new Boolean[3][3];
        List<player> team1 = new ArrayList<>();
        List<player> team2 = new ArrayList<>();
        for(int i=0;i<3;i++) {
            System.out.println(clan1.getClan_name() + ", enter the nickname or username of player number " + i+1);
            t:
            for(Users user : Users.users) {
                if (this.input.nextLine().equals(user.get_name())) {
                    team1.add(new player(user, 100, 0, 4));
                    break t;
                }
            }
        }
        for(int i=0;i<3;i++) {
            System.out.println(clan2.getClan_name() + ", enter the nickname or username of player number " + i+1);
            t:
            for(Users user : Users.users) {
                if (this.input.nextLine().equals(user.get_name())) {
                    team2.add(new player(user, 100, 0, 4));
                    break t;
                }
            }
        }
        for(int i=0;i<3;i++) {
            for(int j=0;j<3;j++) {
                new local2players(team1.get(i).get_user(), team2.get(j).get_user(), board, false);
            }
        }
    }
}