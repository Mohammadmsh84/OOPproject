import java.util.ArrayList;
import java.util.List;

public class Cards {

    private int accuracy, duration, price, player_damage;
    private String card_name;

    public static List<Cards> cards = new ArrayList<>();

    public Cards(int accuracy, int duration, int price, int player_damage, String card_name) {

        this.accuracy=accuracy;
        this.price=price;
        this.player_damage=player_damage;
        this.duration=duration;
        this.card_name=card_name;
        cards.add(this);

    }

    public void setCard_name(String card_name) {
        this.card_name = card_name;
    }

    public String getCard_name() {
        return card_name;
    }

    public void set_accuracy(int p) {
        this.accuracy=p;
    }

    public int get_accuracy() {
        return this.accuracy;
    }

    public void set_duration(int i) {
        this.duration=i;
    }

    public int getDuration() {
        return duration;
    }

    public void setPlayer_damage(int player_damage) {
        this.player_damage = player_damage;
    }

    public int getPlayer_damage() {
        return player_damage;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

    public void setCards(List<Cards> cards) {
        Cards.cards = cards;
    }

    public List<Cards> getCards() {
        return Cards.cards;
    }
}

