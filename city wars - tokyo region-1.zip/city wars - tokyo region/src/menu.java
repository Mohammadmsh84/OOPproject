public interface menu {

    Object[][] board = new Object[2][22];

}