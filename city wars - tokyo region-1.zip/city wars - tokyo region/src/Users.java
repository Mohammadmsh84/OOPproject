import java.util.ArrayList;
import java.util.List;

public class Users {

    private int coins, level;
    private String name, gmail, password, nickname, passquestion, ans;
    private List<Cards> inventory = new ArrayList<>();
    public static List <Users> users = new ArrayList<>();

    public Users(String name, String gmail, String password, String nickname, String passquestion, String ans, int level, int coins) {
        this.name=name;
        this.gmail=gmail;
        this.password=password;
        this.nickname=nickname;
        this.passquestion=passquestion;
        this.ans = ans;
        this.level=level;
        this.coins=coins;
        users.add(this);
    }

    public void setCoins(int coins) {
        this.coins = coins;
    }

    public int getCoins() {
        return coins;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    public void setInventory(List<Cards> inventory) {
        this.inventory = inventory;
    }

    public List<Cards> getInventory() {
        return inventory;
    }

    public static List <Users> getUsers() {
        return users;
    }

    public static void setUsers(List<Users> users) {
        Users.users = users;
    }

    public void set_name(String name) {
        this.name = name;
    }

    public String get_name() {
        return this.name;
    }

    public void setGmail(String gmail) {
        this.gmail = gmail;
    }

    public String getGmail() {
        return gmail;
    }

    public void set_password(String password) {
        this.password=password;
    }

    public String get_password() {
        return this.password;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getNickname() {
        return nickname;
    }

    public void setPassquestion(String passquestion) {
        this.passquestion = passquestion;
    }

    public String getPassquestion() {
        return passquestion;
    }

    public void setAns(String ans) {
        this.ans = ans;
    }

    public String getAns() {
        return this.ans;
    }
}