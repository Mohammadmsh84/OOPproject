import java.util.ArrayList;
import java.util.List;

public class spellCards extends Cards {

    private String spellName;
    private int accuracy, duration, price, player_damage;

   public static List<spellCards> spell_cards = new ArrayList<>();

    public spellCards(int accuracy, int duration, int price, int player_damage, String spellname) {
        super(accuracy, price, player_damage, duration, spellname);
        spell_cards.add(this);
    }


    public void setCard_name(String card_name) {
        this.spellName = card_name;
    }

    public String getCard_name() {
        return spellName;
    }

    public void set_accuracy(int p) {
        this.accuracy=p;
    }

    public int get_accuracy() {
        return this.accuracy;
    }

    public void set_duration(int i) {
        this.duration=i;
    }

    public int getDuration() {
        return duration;
    }

    public void setPlayer_damage(int player_damage) {
        this.player_damage = player_damage;
    }

    public int getPlayer_damage() {
        return player_damage;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }
}