import  java.util.ArrayList;
import java.util.List;


public class player {

    private int hp, damage, turns_left;
    String name;
    private Users user;

    public static List<player> players = new ArrayList<>();

    public player(Users user, int hp, int damage, int turns_left) {

        this.user = user;
        this.name = user.getNickname();
        this.hp = hp;
        this.damage = damage;
        players.add(this);

    }

    public void set_user(Users user) {
        this.user = user;
    }

    public Users get_user() {
        return this.user;
    }

    public void set_turns_left(int a) {
        this.turns_left = a;
    }

    public int get_turns_left() {
        return this.turns_left;
    }

    public void set_players(List<player> players) {
        player.players = players;
    }

    public List<player> get_players() {
        return players;
    }

    public void set_name(String new_name) {
        this.name = new_name;
    }

    public String get_name() {
        return this.name;
    }

    public void set_hp(int hp) {
        this.hp = hp;
    }

    public int get_hp() {
        return this.hp;
    }

    public void set_damage(int damage) {
        this.damage = damage;
    }

    public int get_damage() {
        return this.damage;
    }

}