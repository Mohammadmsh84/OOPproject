import java.util.Scanner;

public class shop {

    Scanner input = new Scanner(System.in);

    public shop (Users user) {
        System.out.println("These cards are now available to purchase :");
        System.out.println("default cards : ");
        int count=0;
        for (defaultCards card : defaultCards.default_cards) {
            System.out.println(count++ + "- " + card.getCard_name() + "price : " + card.getPrice());
        }
        System.out.println("spell cards : ");
        count=0;
        for (spellCards card : spellCards.spell_cards) {
            System.out.println(count++ + "- " + card.getCard_name() + "price : " + card.getPrice());
        }
        System.out.println("enter the name of the card you want to buy");
        String card_name=this.input.nextLine();
        for (Cards card : Cards.cards) {
            if (card.getCard_name().equals(card_name)) {
                System.out.println("card " + card_name + " with price " + card.getPrice() + ".\n are you confident of your purchase ? (y for yes and n for no)");
                if (this.input.nextLine().equals("y")) {
                    if (user.getCoins()>=card.getPrice()) {
                        user.setCoins(user.getCoins()-card.getPrice());
                        (user.getInventory()).add(card);
                        System.out.println("purchase successful");
                        break;
                    }
                }
                else    return;
            }
        }
    }
}