import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class local2players extends game {

    public int final_round=4;
    public int round=1;

    public local2players(Users player1, Users player2, Object[][] board, Boolean guest) {
        super(4, 2);
        player p1=new player(player1, 100, 0, 4);
        player p2=new player(player2, 100, 0, 4);
        int rounds_for_p1=0, rounds_for_p2=0;
        
        if (guest) {
            System.out.println("guest player" + player2.get_name() + "here's your cards for this match");
            List<Cards> one_time_cards=this.random_cards();
            player2.setInventory(one_time_cards);
            System.out.println(one_time_cards);
        }
        
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                int remainig = 5;
                if (remainig>0) {
                    System.out.println(" The game starts in " + remainig + " seconds .");
                    remainig--;
                }
                else {
                    timer.cancel();
                }
            }
        },0, 5000);
        while (round<=final_round) {

            int first = rand.nextInt(1, 3);
            if (first==1) {
                board[0][0] = p1.get_turns_left();
                board[0][21] = p1.get_damage();
                board[1][0] = p2.get_turns_left();
                board[1][21] = p2.get_damage();
                System.out.println("round " + round + " first turn by" + p1.get_name());
                List<Cards> playableCards1 = new ArrayList<>();
                for (int i = 0; i < 5; i++) {
                    int index = rand.nextInt(0, player1.getInventory().size());
                    playableCards1.add(player1.getInventory().get(index));
                }
                List<Cards> playableCards2 = new ArrayList<>();
                for (int i = 0; i < 5; i++) {
                    int index = rand.nextInt(0, player2.getInventory().size());
                    playableCards2.add(player2.getInventory().get(index));
                }
                while (p1.get_turns_left() != 0 && p2.get_turns_left() != 0 && p1.get_hp()>0 && p2.get_hp()>0) {
                    player_hand(player1, playableCards1, true);
                    print_board(p1);
                    player_hand(player2, playableCards2, false);
                    options(p1, p2, playableCards1, playableCards2, true);
                    p1.set_turns_left(p1.get_turns_left()-1);
                    int index = rand.nextInt(0, player1.getInventory().size());
                    playableCards1.add(player1.getInventory().get(index));
                    player_hand(player1, playableCards1, true);
                    print_board(p2);
                    options(p2, p1, playableCards2, playableCards1, false);
                    p2.set_turns_left(p2.get_turns_left()-1);
                }

            }
            else {
                board[0][0]=p2.get_turns_left();
                board[0][21]=p1.get_damage();
                board[1][0]=p1.get_turns_left();
                board[1][21]=p1.get_damage();
                System.out.println("round " + round + " first turn by" + p2.get_name());
                List<Cards> playableCards1 = new ArrayList<>();
                for(int i=0;i<5;i++) {
                    int index=rand.nextInt(0, player1.getInventory().size());
                    playableCards1.add(player1.getInventory().get(index));
                }
                List<Cards> playableCards2 = new ArrayList<>();
                for(int i=0;i<5;i++) {
                    int index=rand.nextInt(0, player2.getInventory().size());
                    playableCards2.add(player2.getInventory().get(index));
                }
                while (p1.get_turns_left() != 0 && p2.get_turns_left() != 0 && p1.get_hp()>0 && p2.get_hp()>0) {
                    player_hand(player2, playableCards2, true);
                    print_board(p2);
                    player_hand(player1, playableCards1, false);
                    options(p2, p1, playableCards2, playableCards1, true);
                    p2.set_turns_left(p2.get_turns_left()-1);
                    int index=rand.nextInt(0, player2.getInventory().size());
                    playableCards2.add(player2.getInventory().get(index));
                    player_hand(player2, playableCards2, true);
                    print_board(p1);
                    player_hand(player1, playableCards1, false);
                    options(p1, p2, playableCards1, playableCards2, false);
                    p1.set_turns_left(p1.get_turns_left()-1);
                }
                if(p1.get_turns_left()==0 && p2.get_turns_left()==0) {
                    System.out.println("round has been ended");
                    round++;
                }
                Boolean w1=p1.get_damage()>p2.get_hp(), w2=p2.get_damage()>p1.get_hp(), d1=p1.get_damage()>p2.get_damage(), d2=p1.get_damage()<p2.get_damage() ;
                if ( (w1 || w2) && p1.get_turns_left()==p2.get_turns_left()) {
                    System.out.println("round is already finished ! ");
                    if (d1 && !d2) {
                        System.out.println(p1.get_name() + " won the round !");
                        rounds_for_p1++;
                    }
                    if (!d1 && d2) {
                        System.out.println(p2.get_name() + "won the round !");
                        rounds_for_p2++;
                    }
                    if (!d1 && !d2) {
                        System.out.println("this round is draw");
                    }
                    round++;
                }
            }
        }
        System.out.println("the match has just finished !");
        if (rounds_for_p1>rounds_for_p2) {
            System.out.println(player1.get_name() + " is the winner of the match !" + rounds_for_p1 + " - " + rounds_for_p2);
        }
        else if (rounds_for_p2>rounds_for_p1) {
            System.out.println(player2.get_name() + " is the winner of the match ! " + rounds_for_p1 + " - " + rounds_for_p2 );
        }
        else {
            System.out.println("draw with " + rounds_for_p1 + " - " + rounds_for_p2);
        }
    }
}