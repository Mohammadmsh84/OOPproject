import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Pattern;
// import com.opencsv.CSVWriter;


public class Main implements menu {

    Random rand = new Random();
    Scanner input = new Scanner(System.in);
    final String url = "jdbc:mysql://localhost:3306/CityWarsTokyoReign";
    final String user = "root";
    final String password = "sam@rad20";
    public String splitter=", ";



    public static void main(String[] args) {
        try {
            new Main();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    Main () throws IOException {
        while (true) {
            loadUsers();
            loadCards();
            loadClans();

            while(getUserData() == null) {
                System.out.println("please enter your choice\n1.sign up menu\n2.login menu\n3.profile page");
                int choice = input.nextInt();
                input.nextLine();
                switch (choice) {
                    case 1:
                        this.SignUp();
                        break;
                    case 2:
                        try{
                            System.out.println("Enter the username of your account : ");
                            String specifier = this.input.nextLine();
                            System.out.println("Enter the password of your account : ");
                            String password = this.input.nextLine();
                            this.login(specifier, password);
                            saveUsers();
                        } catch(IOException var7) {
                            var7.printStackTrace();
                        }
                        break;
                    case 3:
                        if(getUserData() != null) {
                            profile_page(getUserData());
                        }
                        break;
                    default:
                        System.out.println("invalid choice . please try again");
                        break;
                }
            }
            load_inventory(getUserData());
            Users user = getUserData();
            System.out.println("Game Menu\n1.play\n2.inventory\n3.join a clan \n4.shop\n5.view profile\n6.game play history\n7.sign out");
            int choice = input.nextInt();
            input.nextLine();
            switch (choice) {
                case 1:
                    System.out.println("choose game mode");
                    System.out.println("1.local 2 players\n2.Ranked 2 players\n3.clan wars (3v3) \n4.play vs computer\n5.back to menu");
                    int game_mode=input.nextInt();
                    input.nextLine();
                    switch (game_mode) {
                        case 1:
                            System.out.println("sign in with the second player : ( g for guest user ) ");
                            System.out.println("username : ");
                            String username=input.next();
                            if (username.equalsIgnoreCase("g")) {
                                System.out.println("choose a name for your guest user : ");
                                String guest_username = input.next();
                                Users pl2 = new Users(guest_username, null, null, null, null, null, 0, 0);
                                new local2players(user, pl2, board, true);
                                Users.users.remove(pl2);
                            }
                            if (username.equals(user.get_name())) {
                                do {
                                    System.out.println("this user is already in the game . you have to login with another account .");
                                    System.out.println("player two username : ( g for guest )");
                                    username=this.input.next();
                                    if (username.equalsIgnoreCase("g")) {
                                        System.out.println("choose a name for your guest user : ");
                                        String guest_username = input.next();
                                        Users pl2 = new Users( null, null, guest_username, null, null, null, 0, 0);
                                        new local2players(user, pl2, board, false);
                                        Users.users.remove(pl2);
                                    }
                                } while(username.equals(user.get_name()));
                            }
                            for(Users User : Users.users) {
                                if (User.get_name().equals(username)) {
                                    System.out.println("password : ");
                                    String password = input.next();
                                    if (User.get_password().equals(password)) {
                                        System.out.println("successfully logged in as " + User.get_name());
                                        load_inventory(User);
                                        new local2players(user, User, board, false);
                                    }
                                    else {
                                        System.out.println("wrong password");
                                        return;
                                    }
                                }
                                else    continue;
                            }
                            System.out.println("no user with this username");
                            return;
                        case 2:

                            break;
                        case 3:

                            break;
                        case 4:

                            break;
                        case 5:
                            return;
                        default:
                            System.out.println("invalid entry");
                            return;
                    }
                    break;
                case 2:
                    load_inventory(user);
                    System.out.println(user.getInventory());
                    break;
                case 3:
                    break;
                case 4:
                    new shop(user);
                    save_inventory(user, user.getInventory());
                    break;
            }
        }
    }

    public List<Cards> starter_pack() {
        List<Cards> pack = new ArrayList<>();
        for (int i=0;i<12;i++){
            int index=rand.nextInt(16);
            if(Cards.cards.get(index) instanceof defaultCards) {
                pack.add(Cards.cards.get(index));
            }
            else    i--;
        }
        for(int i=0;i<8;i++) {
            int index=rand.nextInt(16);
            if(Cards.cards.get(index) instanceof spellCards) {
                pack.add(Cards.cards.get(index));
            }
            else    i--;
        }
        return pack;
    }

    private void load_inventory(Users user) {
        user.getInventory().clear();
        try {
            List<Cards> inventory = new ArrayList<>();
            File file = new File(user.get_name() +"inventory.txt");
            if (file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line = reader.readLine();
                while(line != null ) {
                    String[] item=line.split(", ");
                    if(item.length==7) {
                        label:
                        for (int i=0;i<Integer.parseInt(item[2]);i++) {
                            for(Cards card:Cards.cards) {
                                if ((card.getCard_name()).equals(item[0] )&&((card.getDuration())==Integer.parseInt(item[4]))&&((card.get_accuracy())==Integer.parseInt(item[3]))&&((card.getPrice())==Integer.parseInt(item[5]))&&((card.getPlayer_damage())==Integer.parseInt(item[6]))) {
                                    inventory.add(card);
                                }
                                else    continue label;
                            }
                        }
                    }
                }
                user.setInventory(inventory);
                reader.close();
            }
            else {
                file.createNewFile();
                BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                writer.write("card name, card type, number of cards, accuracy, duration, price, damage to players");
                writer.close();
            }
        } catch(IOException var8) {
            var8.printStackTrace();
        }
    }

    private void save_clans() throws IOException {
        File file=new File("Clans.txt");
        if (file.exists()) {
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            for(Clans clan : Clans.clans) {
                String s =",";
                writer.write("clan name : " + clan.getClan_name() + s);
                writer.write("members : " + clan.getMembers() + s);
                writer.write("wins : " + clan.getWin() + s);
                writer.write("loses : " + clan.getLose() + s);
                writer.write("draws : " + clan.getDraw() + s);
            }
            writer.close();
        }
        else {
            file.createNewFile();
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            for(Clans clan : Clans.clans) {
                String s =",";
                writer.write("clan name : " + clan.getClan_name() + s);
                writer.write("members : ");
                String sp=", ";
                for(Users user : clan.getMembers()) {
                    writer.write(user.get_name()+sp);
                }
                writer.write(s);
                writer.write("wins : " + clan.getWin() + s);
                writer.write("loses : " + clan.getLose() + s);
                writer.write("draws : " + clan.getDraw() + s);
            }
            writer.close();
        }
    }

    private void loadClans() throws  IOException {
        Clans.clans.clear();
        File file = new File("clans.txt");
        if(file.exists()) {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line = reader.readLine();
            while(line!=null) {
                int wins=0, loses=0, draws=0;
                String clan_name=null;
                List<Users> CM = new ArrayList<>();
                if(line.startsWith("clan name : ")) {
                    clan_name = line.split(" : ")[1];
                }
                if(line.startsWith("members : ")) {
                    String[] members = line.split("members : ");
                    for(String member : members) {
                        shangool:
                        for (Users user : Users.users) {
                            if(member.equals(user.get_name())) {
                                CM.add(user);
                                break shangool;
                            }
                        }
                    }
                }
                if(line.startsWith("wins")) {
                    wins=Integer.parseInt(line.split(" : ")[1]);
                }
                if(line.startsWith("loses")) {
                    loses=Integer.parseInt(line.split(" : ")[1]);
                }
                if(line.startsWith("draws")) {
                    draws=Integer.parseInt(line.split(" : ")[1]);
                }
                new Clans(CM, clan_name, wins, loses, draws, null);
                reader.close();
            }
        }
        else{
            file.createNewFile();
        }
    }



    private void save_inventory(Users user, List<Cards> inventory) {
        try{
            File file = new File(user.get_name() + "inventory.txt");
            if (file.exists()) {
                BufferedWriter r = new BufferedWriter(new FileWriter(file));
                for(int i=0;i<user.getInventory().size();i++) {
                    Cards ThisCard=user.getInventory().get(i);
                    int count=1;
                    for(Cards card : user.getInventory()) {
                        if(card.getCard_name().equals(ThisCard.getCard_name())) count++;
                        else    continue;
                    }
                    String spliter = ", ";
                    r.write(ThisCard.getCard_name() + spliter + ThisCard.getClass() + spliter + count + spliter + ThisCard.get_accuracy() + spliter + ThisCard.getDuration() + spliter + ThisCard.getPrice() + spliter + ThisCard.getPlayer_damage()+",");
                }
                r.close();
            } else {
                file.createNewFile();
                BufferedWriter r = new BufferedWriter(new FileWriter(file));
                for(int i=0;i<user.getInventory().size();i++) {
                    Cards ThisCard=user.getInventory().get(i);
                    int count=1;
                    for(Cards card : user.getInventory()) {
                        if(card.getCard_name().equals(ThisCard.getCard_name())) count++;
                        else    continue;
                    }
                    String splitter = ", ";
                    r.write(ThisCard.getCard_name() + splitter + ThisCard.getClass() + splitter + count + splitter + ThisCard.get_accuracy() + splitter + ThisCard.getDuration() + splitter + ThisCard.getPrice() + splitter + ThisCard.getPlayer_damage()+",");
                }
                r.close();
            }
        } catch(IOException var10) {
            var10.printStackTrace();
        }
    }

    private void profile_page(Users user) {
        System.out.println("Username : " + user.get_name() + ", Password : " + user.get_password() + ", Gmail : " + user.getGmail() + ", nickname : " + user.getNickname() + ", Pass Question : " + user.getPassquestion() + ", Answer : " + user.getAns() + ", Level : " + user.getLevel() + ", coins : " + user.getCoins() + ",");
    }

    private void loadCards() {
        Cards.cards.clear();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CityWarsTokyoRegion")) {
            String sql = "SELECT * FROM cards";
            
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1);
        
            ResultSet resultSet = statement.executeQuery();
        
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String cardName = resultSet.getString("card_name");
                int level = resultSet.getInt("level");
                        switch (cardName) {
                            case "nerf":
                                new spellCards(0, 0, 50, 0, values[i]);
                                break;
                            case "buff":
                                new spellCards(0, 0, 50, 0, values[i]);
                                break;
                            case "round decrease":
                                new spellCards(0, 0, 100, 0, values[i]);
                                break;
                            case "steal":
                                new spellCards(0, 0, 50, 0, values[i]);
                                break;
                            case "heal":
                                new spellCards(0, 0, 50, 0, values[i]);
                                break;
                            case "repair":
                                new spellCards(0, 0, 50, 0, values[i]);
                                break;
                            case "destruct":
                                new spellCards(0, 0, 50, 0, values[i]);
                                break;
                            case "swap locations":
                                new spellCards(0, 0, 50, 0, values[i]);
                                break;
                            case "common atack":
                                new defaultCards(Integer.parseInt(values[i+1]), Integer.parseInt(values[i+2]), Integer.parseInt(values[i+3]), Integer.parseInt(values[i+4]), values[i]);
                                break;
                            case "rare atack":
                                new defaultCards(Integer.parseInt(values[i+1]), Integer.parseInt(values[i+2]), Integer.parseInt(values[i+3]), Integer.parseInt(values[i+4]), values[i]);
                                break;
                            case "epic atack":
                                new defaultCards(Integer.parseInt(values[i+1]), Integer.parseInt(values[i+2]), Integer.parseInt(values[i+3]), Integer.parseInt(values[i+4]), values[i]);
                                break;
                            case "legend atack":
                                new defaultCards(Integer.parseInt(values[i+1]), Integer.parseInt(values[i+2]), Integer.parseInt(values[i+3]), Integer.parseInt(values[i+4]), values[i]);
                                break;
                            case "common shield":
                                new defaultCards(Integer.parseInt(values[i+1]), Integer.parseInt(values[i+2]), Integer.parseInt(values[i+3]), Integer.parseInt(values[i+4]), values[i]);
                                break;
                            case "rare shield":
                                new defaultCards(Integer.parseInt(values[i+1]), Integer.parseInt(values[i+2]), Integer.parseInt(values[i+3]), Integer.parseInt(values[i+4]), values[i]);
                                break;
                            case "epic shield":
                                new defaultCards(Integer.parseInt(values[i+1]), Integer.parseInt(values[i+2]), Integer.parseInt(values[i+3]), Integer.parseInt(values[i+4]), values[i]);
                                break;
                            case "legend shield":
                                new defaultCards(Integer.parseInt(values[i+1]), Integer.parseInt(values[i+2]), Integer.parseInt(values[i+3]), Integer.parseInt(values[i+4]), values[i]);
                                break;
                            default:
                                continue label;
                        }
            }
        }
    }

    private void loadUsers() {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CityWarsTokyoRegion", "username", "password"))
        String sql="SELECT * FROM Users";    
        PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1);
        
            ResultSet resultSet = statement.executeQuery();
        
            while (resultSet.next()) {
                int xp = resultSet.getInt("xp");
                int coins = resultSet.getInt("coins");
                String name = resultSet.getString("username");
                int level = resultSet.getInt("level");
                String gmail = resultSet.getString("gmail");
                String nickname = resultset.getString("nickname")
                String sec_ans=resultSet.getString("security_answer");
                String sec_question=resultSet.getString("security_question");
    }

    private Users getUserData() {
        Users user=null;
        try {
            File file = new File("user.txt");
            if (file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line = reader.readLine();
                while(line != null) {
                    String[] data = line.split(", ");
                    if (data.length == 8) {
                        File other_file=new File("Users.txt");
                        BufferedReader reader2=new BufferedReader(new FileReader(other_file));
                        String other_line=reader2.readLine();
                        while (other_line!=null) {
                            String[] other_data=other_line.split(splitter);
                            if (other_data.length==8) {
                                reader.close();
                                reader2.close();
                                user=new Users(data[0], data[1], data[2], data[3], data[4], data[5], Integer.parseInt(data[6]), Integer.parseInt(data[7]));
                            }
                        }
                    }
                }
            } else {
                file.createNewFile();
            }
        } catch (IOException var5) {
            var5.printStackTrace();
        }
        return user;
    }

    private void saveUsers() {
        try {
            File myFile = new File("Users.txt");
            if (myFile.exists()) {
                BufferedWriter writer = new BufferedWriter(new FileWriter(myFile));
                for(int i = 0; i < Users.users.size(); ++i) {
                    Users user = Users.users.get(i);
                    writer.write(user.get_name() + splitter + user.getGmail() + splitter + user.get_password() + splitter + user.getNickname() + splitter + user.getPassquestion() + splitter + user.getAns() + splitter + user.getLevel() + splitter + user.getCoins() + ",");
                    if (i != Users.users.size() - 1) {
                        writer.write("\n");
                    }
                }
                writer.close();
            } else {
                myFile.createNewFile();
                BufferedWriter writer = new BufferedWriter(new FileWriter(myFile));
                writer.write("Username, Gmail, Password, Nickname, Pass Question, Answer, Level, Coins");
                for(int i = 0; i < Users.users.size(); ++i) {
                    Users user = Users.users.get(i);
                    writer.write(user.get_name() + splitter + user.getGmail() + splitter + user.get_password() + splitter + user.getNickname() + splitter + user.getPassquestion() + splitter + user.getAns() + splitter + user.getLevel() + splitter + user.getCoins()+",");
                    if (i != Users.users.size() - 1) {
                        writer.write("\n");
                    }
                }
                writer.close();
            }
        } catch (IOException var5) {
            var5.printStackTrace();
            System.out.println("IOException, " + var5.getMessage());
        }
    }

    private void saveThisUser(Users user) {
        try {
            File file = new File("Users.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            if(file.exists()) {
                writer.write(user.get_name() + splitter + user.getGmail() + splitter + user.get_password() + splitter + user.getNickname() + splitter + user.getPassquestion() + splitter + user.getAns() + splitter + user.getLevel() + splitter + user.getCoins() + ",");
                Users.users.add(user);
                writer.close();
            } else {
                file.createNewFile();
                writer.write("Username, Gmail, Password, Nickname, Pass Question, Answer, Level, Coins");
                writer.write(user.get_name() + splitter + user.getGmail() + splitter + user.get_password() + splitter + user.getNickname() + splitter + user.getPassquestion() + splitter + user.getAns() + splitter + user.getLevel() + user.getCoins() + ",");
                Users.users.add(user);
                writer.close();
            }

            File File = new File("user.txt");
            BufferedWriter Writer = new BufferedWriter(new FileWriter(File));
            if(File.exists()) {
                Writer.write(user.get_name() + splitter + user.getGmail() + splitter + user.get_password() + splitter + user.getNickname() + splitter + user.getPassquestion() + splitter + user.getAns() + splitter + user.getLevel() + splitter + user.getCoins() + ",");
                Users.users.add(user);
                Writer.close();
            } else {
                File.createNewFile();
                Writer.write("Username, Gmail, Password, Nickname, Pass Question, Answer, Level, Coins");
                Writer.write(user.get_name() + splitter + user.getGmail() + splitter + user.get_password() + splitter + user.getNickname() + splitter + user.getPassquestion() + splitter + user.getAns() + splitter + user.getLevel() + splitter + user.getCoins() + ",");
                Users.users.add(user);
                Writer.close();
            }
        } catch (IOException var1) {
            var1.printStackTrace();
        }
    }

    public void SignUp() {
        while(true) {
            System.out.println("Enter your username :");
            String username = this.input.nextLine();
            for(Users user : Users.users) {
                if (user.get_name().equals(username)) {
                    do {
                        System.out.println("This username is already taken");
                        username = this.input.nextLine();
                    } while (user.get_name().equals(username));
                }
                else    continue;
            }
            System.out.println("Enter your password : (Enter random for a random password)");
            String password = this.input.nextLine();
            if (password.equalsIgnoreCase("random")) {
                StringBuilder Password = new StringBuilder();
                do {
                    Password.setLength(0);
                    int len = rand.nextInt(8, 21);
                    for(int i=0;i<=len;i++) {
                        char randomchar = "[a-zA-Z0-9]".charAt(rand.nextInt(36));
                        Password.append(randomchar);
                    }
                } while(Pattern.compile("[a-zA-Z0-9]{8,20}").matcher(Password).matches());
                password=Password.toString();
                System.out.println("here's your random password : " + password);
            }
            System.out.println("confirm your password : ");
            String confirm_password = this.input.nextLine();
            if (!confirm_password.equals(password)) {
                do {
                    System.out.println("passwords do not match . Enter your password again (b to return)");
                    confirm_password=this.input.nextLine();
                } while (!confirm_password.equals(password) && !confirm_password.equalsIgnoreCase("b"));
                if (confirm_password.equalsIgnoreCase("b")) {
                    return;
                }
            }
            else {
                System.out.println("Enter your email");
                String gmail = this.input.nextLine();
                if (Pattern.compile("^[a-zA-Z0-9._%+-]+@gmail.com$").matcher(gmail).matches()) {
                    System.out.println("Enter a nickname for yourself : ");
                }
                else {
                    do {
                        System.out.println("invalid gmail . please enter again");
                        gmail = this.input.nextLine();
                    } while (!Pattern.compile("^[a-zA-Z0-9._%+-]+@gmail.com$").matcher(gmail).matches());
                    System.out.println("enter a nick name for yourself");
                }
                String nickname = this.input.nextLine();
                if (Pattern.compile("^[a-zA-Z0-9._%+-]+").matcher(nickname).matches()) {
                    System.out.println("user created successfully . choose one of these three security questions to answer about your self .");
                }
                else {
                    do {
                        System.out.println("nick name dosn't match . \n please enter again .");
                        nickname = this.input.nextLine();
                    } while (Pattern.compile("^[a-zA-Z0-9._%+-]+").matcher(nickname).matches());
                    System.out.println("user created successfully . choose one of these three security questions to answer about your self .");
                }
                String[] q = new String[3];
                q[0] = "what is your father's name ?";
                q[1] = "what's your favpurote color ?";
                q[2] = "what was the name of your first pet ?";
                System.out.println("1." + q[0] + "\n2." + q[1] + "\n3." + q[2]);
                int select = this.input.nextInt();
                this.input.nextLine();
                switch (select) {
                    case 1:
                        System.out.println(q[0]);
                        break;
                    case 2:
                        System.out.println(q[1]);
                        break;
                    case 3:
                        System.out.println(q[2]);
                        break;
                    default:
                        System.out.println("invalid entry");
                        return;
                }
                String answer = this.input.nextLine();
                Users newUser=new Users(username, gmail, confirm_password, nickname,q[select-1], answer, 1, 200);
                saveThisUser(newUser);
                System.out.println("Welcome to the game ! We have a starter pack for you ! ");
                List<Cards> starter_pack=this.starter_pack();
                newUser.setInventory(starter_pack);
                save_inventory(newUser, newUser.getInventory());
                saveUsers();
            }
        }
    }

    public void login(String username, String password) throws IOException {
        try {
            File file = new File("Users.txt");
            if(file.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line = reader.readLine();
                while (line != null) {
                    if (line.contains(username)) {
                        if(line.contains(password)) {
                            System.out.println("successfully logged in .");
                        }
                        else {
                            do {
                                Timer timer = new Timer();
                                timer.schedule(new TimerTask() {
                                    @Override
                                    public void run() {
                                        int remaining = 5;
                                        if (remaining>0) {
                                            System.out.println("wrong password . try again in " + remaining + " seconds .");
                                            remaining--;
                                        }
                                        else {
                                            timer.cancel();
                                        }
                                    }
                                },0, 5000);
                                System.out.println("password : ");
                                password = this.input.nextLine();
                            } while (!line.contains(password));
                        }
                        try {
                            File userFile = new File("user.txt");
                            BufferedWriter writer = new BufferedWriter(new FileWriter(userFile));
                            writer.write("");
                            writer.write(line);
                            writer.close();
                        } catch(IOException  var5) {
                            var5.printStackTrace();
                        }
                        String[] data = line.split(", ");
                        if (data.length == 8) {
                            Users newUser = new Users(data[0], data[1], data[2],  data[3], data[4], data[5], Integer.parseInt(data[6]), Integer.parseInt(data[7]));
                            saveThisUser(newUser);
                        }
                    }
                    else {
                        System.out.println("there are no users with this username");
                        return;
                    }
                    reader.close();
                }
            } else {
                file.createNewFile();
            }
        } catch (FileNotFoundException var3) {
            var3.printStackTrace();
        }
    }
}