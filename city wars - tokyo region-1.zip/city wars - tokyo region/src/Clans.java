import java.util.ArrayList;
import java.util.List;

public class Clans {

    List<Users> members;
    String clan_name;
    int win, draw, lose;
    ArrayList<ClanWars> history;
    public static List<Clans> clans = new ArrayList<>();
    
    public Clans (List<Users> members, String clan_name, int win, int draw, int lose, ArrayList<ClanWars> history) {
        this.clan_name=clan_name;
        this.members=members;
        this.draw=draw;
        this.lose=lose;
        this.win=win;
        this.history=history;
        clans.add(this);
    }

    public void setClan_name(String clan_name) {
        this.clan_name = clan_name;
    }

    public String getClan_name() {
        return clan_name;
    }

    public void setHistory(ArrayList<ClanWars> history) {
        this.history = history;
    }

    public ArrayList<ClanWars> getHistory() {
        return history;
    }

    public void setDraw(int draw) {
        this.draw = draw;
    }

    public int getDraw() {
        return draw;
    }

    public void setLose(int lose) {
        this.lose = lose;
    }

    public int getLose() {
        return lose;
    }

    public void setWin(int win) {
        this.win = win;
    }

    public int getWin() {
        return win;
    }

    public static void setClans(List<Clans> clans) {
        Clans.clans = clans;
    }

    public static List<Clans> getClans() {
        return clans;
    }

    public void setMembers(List<Users> members) {
        this.members = members;
    }

    public List<Users> getMembers() {
        return members;
    }
}