import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class game {
    private int rounds;
    private int playersNumber;
    private static final Random rand = new Random();
    private static final Scanner input = new Scanner(System.in);

    public Game(int rounds, int playersNumber) {
        this.rounds = rounds;
        this.playersNumber = playersNumber;
    }

    public int getRounds() {
        return rounds;
    }

    public void setRounds(int rounds) {
        this.rounds = rounds;
    }

    public int getPlayersNumber() {
        return playersNumber;
    }

    public void setPlayersNumber(int playersNumber) {
        this.playersNumber = playersNumber;
    }

    public List<Card> randomCards() {
        List<Card> pack = new ArrayList<>();
        for (int i = 0; i < 12; i++) {
            int index = rand.nextInt(Cards.cards.size());
            if (Card.cards.get(index) instanceof defaultCards) {
                pack.add(Card.cards.get(index));
            } else {
                i--;
            }
        }
        for (int i = 0; i < 8; i++) {
            int index = rand.nextInt(Cards.cards.size());
            if (Card.cards.get(index) instanceof spellCard) {
                pack.add(Card.cards.get(index));
            } else {
                i--;
            }
        }
        return pack;
    }

    public void playerHand(User user, List<Card> playerCards, boolean firstPlayer) {
        System.out.println(user.getName());
        System.out.println("     1          2          3          4          5");
        System.out.println("╔══════════╦══════════╦══════════╦══════════╦══════════╗");
        for (int i = 0; i < 5; i++) {
            String cardName = playerCards.get(i).getCardName();
            System.out.print(" " + cardName.substring(0, 1) + cardName.substring(cardName.length() - 2, cardName.length() - 1) + " ║");
        }
        System.out.println("\n╚══════════╩══════════╩══════════╩══════════╩══════════╝");
        if (!firstPlayer) {
            System.out.println("\n--------------------------------------------------------------------------");
        }
    }


    public void options(player player, player opponent, List<Cards> player_cards, List<Cards> opponent_cards, Boolean user_on_top) {
        try {
            System.out.println("Enter the number of card you want to play ( 1-5 from left to right )");
            int choose=input.nextInt();
            switch(player_cards.get(choose-1).getCard_name()) {
                case "common shield":
                case "rare shield":
                case "epic shield":
                case "legend shield":
                case "common atack":
                case "rare atack":
                case "epic atack":
                case "legend atack":
                    System.out.println("choose the first block you want to place your card in (1-20 from left to right)");
                    System.out.println("your card duration : " + player_cards.get(choose-1).getDuration());
                    int block=input.nextInt();
                    input.nextLine();
                    int x, y;
                    // placing card in the specified block
                    if (user_on_top) {
                        if(player_cards.get(choose-1).getDuration()==1) board[0][block]=player_cards.get(choose-1);
                        else {
                            for (int i=block ; i<=player_cards.get(choose-1).getDuration() ; i++) {
                                if(board[0][i]!="BR") {
                                    board[0][block] = player_cards.get(choose - 1);
                                }
                            }
                        }
                        x=0;
                    }
                    else {
                        if(player_cards.get(choose-1).getDuration()==1) board[1][block]=player_cards.get(choose-1);
                        else {
                            for (int i=block ; i<=player_cards.get(choose-1).getDuration() ; i++) {
                                if(board[1][i]=="BR") {
                                    board[1][block] = player_cards.get(choose - 1);
                                }
                            }
                        }
                        x=1;
                    }
                    y=player_cards.get(choose-1).getDuration();
                    // handling card's affection on the board
                    for(int j=block;j<=y;j++) {
                        Cards opposite_card=((Cards)board[(x+1)%2][j]);
                        Cards player_card=(Cards)board[x][j];
                        if(opposite_card.get_accuracy()<player_card.get_accuracy()) {
                            board[(x+1)%2][j]=null;
                            opponent.set_damage(opponent.get_damage()-opposite_card.getPlayer_damage());
                            board[(x+1)%2][21]=opponent.get_damage();
                            player.set_damage(player.get_damage()+player_card.getPlayer_damage());
                            board[x][21]=player.get_damage();
                        } else if (opposite_card.get_accuracy()==player_card.get_accuracy()) {
                            board[(x+1)%2][j]=null;
                            opponent.set_damage(opponent.get_damage()-opposite_card.getPlayer_damage());
                            board[(x+1)%2][21]=opponent.get_damage();
                            board[x][j]=null;
                        }
                        else {
                            board[x][j]=null;
                        }
                    }
                case "swap locations":
                    System.out.println("Enter the location of the card you want to change its location ?");
                    System.out.println("x : ");
                    x=input.nextInt();
                    System.out.println("y : ");
                    y=input.nextInt();
                    int dy=0, dx=0;
                    if(x>=1 && x<=2 && y>=1 && y<=20) {
                        System.out.println("Enter the direct location for that card");
                        System.out.println("x : ");
                        dx=input.nextInt();
                        System.out.println("y : ");
                        dy=input.nextInt();
                        if(!(dx>=1 && dx<=2 && dy>=1 && dy<=20)) {
                            do {
                                System.out.println("choose a location in the board");
                                System.out.println("x : ");
                                dx=input.nextInt();
                                System.out.println("y : ");
                                dy=input.nextInt();
                            } while (!(dx>=1 && dx<=2 && dy>=1 && dy<=20));
                        }
                    }
                    else {
                        do {
                            System.out.println("choose a location in the board");
                            System.out.println("x : ");
                            x=input.nextInt();
                            System.out.println("y : ");
                            y=input.nextInt();
                        } while(!(x>=1 && x<=2 && y>=1 && y<=20));
                    }
                    Cards target_card = (Cards) board[x-1][y-1];
                    if(dy+(target_card.getDuration()-1)<=21) {
                        int count=0;
                        for(int i=dy;i<=target_card.getDuration()+dy-1;i++){
                            if(board[dx-1][i]==null) {
                                count++;
                            }
                        }
                        if (count == target_card.getDuration()) {
                            System.out.println("the card successfully changed its location");
                            for(int i=dy;i<=target_card.getDuration()+dy-1;i++){
                                board[dx-1][i]=target_card;
                            }
                        }
                        else {
                            System.out.println("you chose non empty block(s) in your direction . your turn just got wasted");
                        }
                    }
                    else System.out.println("the card won't be placed in the board because of its duration . unfortunately your turn wasted");
                    break;
                case "buff":
                    System.out.println("which one of your blocks you want to buff ?");
                    block = input.nextInt();
                    if (user_on_top) {
                        if ((Cards) board[0][block] instanceof defaultCards) {
                            Cards player_card = (Cards) board[0][block];
                            List<Integer> similar_cards = new ArrayList<>();
                            for (int i = 1; i < player_card.getDuration(); i++) {
                                if (((Cards) board[0][block - i]).equals(player_card)) {
                                    similar_cards.add(block - i);
                                } else break;
                            }
                            for (int i = 1; i < player_card.getDuration(); i++) {
                                if (((Cards) board[0][block + i]).equals(player_card)) {
                                    similar_cards.add(block + i);
                                } else break;
                            }
                            int final_damage = (int) (((similar_cards.size()+1)*0.2)+player.get_damage());
                            player.set_damage(final_damage);
                            board[0][21]=player.get_damage();
                        } else {
                            System.out.println("you targeted the wrong block . your turn just got wasted .");
                        }
                    }
                    else {
                        if ((Cards) board[1][block] instanceof defaultCards) {
                            Cards player_card = (Cards) board[1][block];
                            List<Integer> similar_cards = new ArrayList<>();
                            for (int i = 1; i < player_card.getDuration(); i++) {
                                if (((Cards) board[1][block - i]).equals(player_card)) {
                                    similar_cards.add(block - i);
                                } else break;
                            }
                            for (int i = 1; i < player_card.getDuration(); i++) {
                                if (((Cards) board[1][block + i]).equals(player_card)) {
                                    similar_cards.add(block + i);
                                } else break;
                            }
                            int final_damage = (int) (((similar_cards.size()+1)*0.2)+player.get_damage());
                            player.set_damage(final_damage);
                            board[1][21]=player.get_damage();
                        }
                        else {
                            System.out.println("you targeted the wrong card . your turn just got wasted");
                        }
                    }
                    break;
                case "nerf" :
                    System.out.println("which one of your opponent blocks you want to nerf ?");
                    block = input.nextInt();
                    if (user_on_top) {
                        if ((Cards) board[1][block] instanceof defaultCards) {
                            Cards player_card = (Cards) board[1][block];
                            List<Integer> similar_cards = new ArrayList<>();
                            for (int i = 1; i < player_card.getDuration(); i++) {
                                if (((Cards) board[1][block - i]).equals(player_card)) {
                                    similar_cards.add(block - i);
                                } else break;
                            }
                            for (int i = 1; i < player_card.getDuration(); i++) {
                                if (((Cards) board[1][block + i]).equals(player_card)) {
                                    similar_cards.add(block + i);
                                } else break;
                            }
                            int final_damage = (int) (((similar_cards.size()+1)*0.2)+player.get_damage());
                            opponent.set_damage(final_damage);
                            board[1][21]=opponent.get_damage();
                        } else {
                            System.out.println("you targeted the wrong block . your turn just got wasted .");
                        }
                    }
                    else {
                        if ((Cards) board[0][block] instanceof defaultCards) {
                            Cards player_card = (Cards) board[0][block];
                            List<Integer> similar_cards = new ArrayList<>();
                            for (int i = 1; i < player_card.getDuration(); i++) {
                                if (((Cards) board[0][block - i]).equals(player_card)) {
                                    similar_cards.add(block - i);
                                } else break;
                            }
                            for (int i = 1; i < player_card.getDuration(); i++) {
                                if (((Cards) board[0][block + i]).equals(player_card)) {
                                    similar_cards.add(block + i);
                                } else break;
                            }
                            int final_damage = (int) (((similar_cards.size()+1)*0.2)+player.get_damage());
                            opponent.set_damage(final_damage);
                            board[0][21]=opponent.get_damage();
                        }
                        else {
                            System.out.println("you targeted the wrong card . your turn just got wasted");
                        }
                    }
                    player_cards.remove(choose-1);
                    break;
                case "steal":
                    System.out.println("from your opponent hands, enter the number of card which you want to steal ( 1-5 from left to right )");
                    int b = input.nextInt();
                    player_cards.remove(choose-1);
                    player_cards.add(opponent_cards.get(b-1));
                    opponent_cards.add(opponent.get_user().getInventory().get(rand.nextInt(0, opponent.get_user().getInventory().size())));
                    return;
                case "destruct":
                    int x3;
                    if (user_on_top)    x3=0;
                    else x3=1;
                    System.out.println("which one of your opponents block you want to destruct ? ( the block must be null )");
                    int c=input.nextInt();
                    board[(x3+1)%2][c]="BR";
                    break;
                case "repair":
                    if (user_on_top) {
                        int count=0;
                        for(int i=1;i<=20;i++) {
                            if(board[0][i]=="BR")   count++;
                        }
                        if (count>1) {
                            System.out.println("enter the block you want to repair");
                            int d=input.nextInt();
                            if(board[0][d]=="BR")   board[0][d]=null;
                            else {
                                do {
                                    System.out.println("the block wasn't null . enter again");
                                    d=input.nextInt();
                                } while(board[0][d]!="BR");
                                board[0][d]=null;
                            }
                        } else {
                            for(int i=1;i<=20;i++) {
                                if (board[0][i]=="BR")  board[0][i]=null;
                            }
                        }
                    } else {
                        int count=0;
                        for(int i=1;i<=20;i++) {
                            if(board[1][i]=="BR")   count++;
                        }
                        if (count>1) {
                            System.out.println("enter the block you want to repair");
                            int d=input.nextInt();
                            if(board[1][d]=="BR")   board[1][d]=null;
                            else {
                                do {
                                    System.out.println("the block wasn't null . enter again");
                                    d=input.nextInt();
                                } while(board[1][d]!="BR");
                                board[1][d]=null;
                            }
                        } else {
                            for(int i=1;i<=20;i++) {
                                if (board[1][i]=="BR")  board[1][i]=null;
                            }
                        }
                    }
                case "round decrease":
                    this.set_rounds(this.get_rounds()-1);
                    return;
                case "heal":
                    player.set_hp(player.get_hp()+50);

            }
        } catch(IndexOutOfBoundsException var11) {
            var11.printStackTrace();
        }

    }

    public void printBoard(Object[][] board) {
        System.out.println("╔═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╦═════╗");
        for (int i = 0; i < board.length; i++) {
            System.out.print("║");
            for (int j = 0; j < board[i].length; j++) {
                if (board[i][j] == null) {
                    System.out.print("     ║");
                } else if (board[i][j] instanceof User) {
                    System.out.print(" " + ((User) board[i][j]).getName() + " ║");
                } else if (board[i][j] instanceof spellCards) {
                    continue;
                } else if (board[i][j] instanceof defaultCards) {
                    String cardName = ((Card) board[i][j]).getCardName();
                    System.out.print(" " + cardName.substring(0, 1) + cardName.substring(cardName.length() - 2, cardName.length() - 1) + " ║");
                } else {
                    String cardName = ((Card) board[i][j]).getCardName();
                    System.out.print(" " + cardName.substring(0, 1) + cardName.substring(cardName.length() - 2, cardName.length() - 1) + " ║");
                }
            }
            System.out.println();
            if (i < board.length - 1) {
                System.out.println("╠═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╬═════╣");
            }
        }
        System.out.println("╚═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╩═════╝");
    }
}